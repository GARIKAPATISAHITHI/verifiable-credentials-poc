type Credential = {
  type: string[];
  issuer: string;
  credentialSubject: { id: string; loyaltyTier: string };
  credentialStatus: { type: string; status: string };
};

const credential: Credential = {
  type: ["VerifiableCredential", "DemoLoyaltyCredential"],
  issuer: "did:web:demo.example",
  credentialSubject: {
    id: "did:key:zDemoHolder",
    loyaltyTier: "gold"
  },
  credentialStatus: {
    type: "DemoStatus",
    status: "active"
  }
};

function verifyBusinessRules(vc: Credential) {
  const checks = {
    hasCredentialType: vc.type.includes("VerifiableCredential"),
    issuerPresent: Boolean(vc.issuer),
    subjectPresent: Boolean(vc.credentialSubject.id),
    statusActive: vc.credentialStatus.status === "active"
  };

  return { valid: Object.values(checks).every(Boolean), checks };
}

console.log(JSON.stringify(verifyBusinessRules(credential), null, 2));
