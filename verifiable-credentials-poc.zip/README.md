# Verifiable Credentials POC

A small TypeScript demonstration of the issuer / holder / verifier model used by Verifiable Credentials.

## Demonstrates
- issuer / holder / verifier roles
- credential metadata
- DID-style identifiers
- credential presentation concepts
- selective-disclosure discussion
- OID4VCI / OID4VP concepts in documentation

This repository is intentionally an educational POC. It is not a production W3C VC, OID4VCI, OID4VP, or SD-JWT VC implementation.

## Example flow

Issuer -> Wallet/Holder -> Verifier

The verifier should independently validate the credential, issuer, audience/presentation context, expiration and cryptographic proof in a production implementation.
